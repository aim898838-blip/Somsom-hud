# Somsom PvP HUD

Fabric client mod for Minecraft 1.21.11.

HUD:
- X/Y/Z coordinates
- FPS
- ping
- player name under the crosshair
- live item cooldown percentages
- active effects and remaining time

## Build

Use Java 21 and Gradle 9.9.1 or the Gradle Wrapper.

```text
gradle build
```

The resulting JAR is in `build/libs/`.

The mod requires Fabric Loader and Fabric API for Minecraft 1.21.11.
