package ru.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Font;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class VisualsClient implements ClientModInitializer {
    private static final int PANEL = 0xB814141A;
    private static final int BORDER = 0xFF2D2D36;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFB9BAC3;
    private static final int ACCENT = 0xFF8B5CF6;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("pulsevisuals", "hud"),
                (HudElement) this::renderHud
        );
    }

    private void renderHud(GuiGraphics g, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui || mc.screen != null) return;

        Font font = mc.font;
        int x = 8;
        int y = 8;
        int width = 155;
        int line = 12;

        List<String> info = new ArrayList<>();
        info.add("XYZ  " + p.getBlockX() + "  " + p.getBlockY() + "  " + p.getBlockZ());
        info.add("FPS  " + mc.getFps());
        info.add("PING " + getPing(p));

        String target = getTargetName(mc);
        info.add("TARGET  " + (target == null ? "—" : target));

        int cooldownLines = Math.min(3, countCooldowns(p));
        int effects = Math.min(4, p.getActiveEffects().size());
        int height = 8 + (info.size() * line) + (cooldownLines > 0 ? 18 + cooldownLines * line : 0)
                + (effects > 0 ? 18 + effects * line : 0) + 8;

        g.fill(x - 1, y - 1, x + width + 1, y + height + 1, BORDER);
        g.fill(x, y, x + width, y + height, PANEL);
        g.fill(x, y, x + 2, y + height, ACCENT);

        int cy = y + 6;
        for (String s : info) {
            String[] split = s.split("  ", 2);
            if (split.length == 2) {
                draw(g, font, split[0], x + 7, cy, ACCENT);
                draw(g, font, split[1], x + 55, cy, WHITE);
            } else draw(g, font, s, x + 7, cy, WHITE);
            cy += line;
        }

        if (cooldownLines > 0) {
            draw(g, font, "COOLDOWNS", x + 7, cy + 2, ACCENT);
            cy += 14;
            int shown = 0;
            for (int slot = 0; slot < p.getInventory().getContainerSize() && shown < 3; slot++) {
                ItemStack stack = p.getInventory().getItem(slot);
                if (stack.isEmpty()) continue;
                float progress = p.getCooldowns().getCooldownPercent(stack.getItem(), tickCounter.getGameTimeDeltaPartialTick(true));
                if (progress <= 0.0f) continue;
                int pct = Math.max(1, Math.round(progress * 100));
                String name = stack.getHoverName().getString();
                if (name.length() > 13) name = name.substring(0, 13);
                draw(g, font, name, x + 7, cy, MUTED);
                drawRight(g, font, pct + "%", x + width - 7, cy, WHITE);
                cy += line;
                shown++;
            }
        }

        if (effects > 0) {
            draw(g, font, "EFFECTS", x + 7, cy + 2, ACCENT);
            cy += 14;
            List<MobEffectInstance> list = new ArrayList<>(p.getActiveEffects());
            list.sort(Comparator.comparing(e -> e.getEffect().value().getName()));
            for (int i = 0; i < Math.min(4, list.size()); i++) {
                MobEffectInstance e = list.get(i);
                String name = e.getEffect().value().getName().getString();
                String time = formatTime(e.getDuration());
                if (name.length() > 16) name = name.substring(0, 16);
                draw(g, font, name, x + 7, cy, MUTED);
                drawRight(g, font, time, x + width - 7, cy, WHITE);
                cy += line;
            }
        }
    }

    private static void draw(GuiGraphics g, Font font, String text, int x, int y, int color) {
        g.drawString(font, text, x, y, color, true);
    }

    private static void drawRight(GuiGraphics g, Font font, String text, int right, int y, int color) {
        g.drawString(font, text, right - font.width(text), y, color, true);
    }

    private static int getPing(LocalPlayer p) {
        if (p.connection == null) return 0;
        var entry = p.connection.getPlayerInfo(p.getUUID());
        return entry == null ? 0 : entry.getLatency();
    }

    private static String getTargetName(Minecraft mc) {
        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult entityHit) {
            Entity e = entityHit.getEntity();
            if (e instanceof Player player) return player.getGameProfile().name();
        }
        return null;
    }

    private static int countCooldowns(LocalPlayer p) {
        int n = 0;
        for (int slot = 0; slot < p.getInventory().getContainerSize(); slot++) {
            ItemStack stack = p.getInventory().getItem(slot);
            if (!stack.isEmpty() && p.getCooldowns().getCooldownPercent(stack.getItem(), 0) > 0) n++;
        }
        return n;
    }

    private static String formatTime(int ticks) {
        int seconds = Math.max(0, ticks) / 20;
        if (seconds >= 60) return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
        return seconds + "s";
    }
}
